//
//  CPProfiler.h
//  CPProfiler
//
//  Created by Laurent Michel on 2/14/18.
//  Copyright © 2018 Laurent Michel. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for CPProfiler.
FOUNDATION_EXPORT double CPProfilerVersionNumber;

//! Project version string for CPProfiler.
FOUNDATION_EXPORT const unsigned char CPProfilerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CPProfiler/PublicHeader.h>

#import <CPProfiler/profiler.h>

