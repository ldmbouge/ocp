
#import <Foundation/Foundation.h>

typedef struct NodeID {
   int _nid;
   int _rid;
   int _tid;
} NodeID;

enum NStatus {NSSolved =0,NSFailed=1,NSBranch=2,NSSkip=3};

@protocol STNode<NSObject>
-(NodeID)getNodeId;
-(void)setLabel:(NSString*)l;
-(void)setNogood:(NSString*)ng;
-(void)setInfo:(NSString*)i;
-(void)increaseKids;
-(void)setNbKids:(int)nbk;
-(void)setStatus:(enum NStatus)s;
-(void)commit;
@end

@protocol Profiler<NSObject>
-(void)connect;
-(void)start:(const char*)fName withIdentifier:(int)rid;
-(void)restart:(const char*)fName withIdentifier:(int)rid;
-(id<STNode>)createNode:(NodeID)nid parent:(NodeID)pid altNumber:(int)an;
-(void)done;
-(void)disconnect;
-(void)tag:(id<STNode>)node label:(NSString*)name with:(int)val;
-(void)tag:(id<STNode>)node diff:(NSString*)name with:(int)val;
-(void)tag:(id<STNode>)node lthen:(NSString*)name with:(int)val;
-(void)tag:(id<STNode>)node gthen:(NSString*)name with:(int)val;
@end

@interface CPPFactory : NSObject
+(id<Profiler>)makeProfiler:(int)portNumber;
@end
